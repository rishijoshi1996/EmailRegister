package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.model.ConfirmationToken;

public interface ConfirmationTokenRepository extends CrudRepository<ConfirmationToken, String> {

	
	ConfirmationToken findByConfirmationToken(String confirmationToken);
}
